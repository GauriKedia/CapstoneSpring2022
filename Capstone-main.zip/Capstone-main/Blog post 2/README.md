Blog post 2
It keeps occurring to me just how much I have to do with this- create an environment from scratch, populate it with living and non-living elements, figure out how each interacts with the other. To make this slightly less impossible for me to keep track of, I started by making categories and lists of things I need to make, like rocks, plants, etc. There will be some overlap between the living and the non-living- like a rock creature or something (like in legend of Zelda https://www.zeldadungeon.net/wiki/images/2/28/Stone-talus.jpeg)
Some disorganised and disjointed thoughts I had when imagining the environment:
-          I'm playing with the idea of bioluminescence for some plants/creatures, that you can only see when it's dark.
-          I'm also considering putting a timer on the lighting, to show the passage of time (accelerated) for night and day.
-          Procedural terrain- this sort of randomizes elements to keep creating an environment as the player/person moves through it. This will make the environment infinite, so to speak, so people can stay in the environment for as long as they want.
-          Adding some sort of tactile sensation to interactions
-          Will the sun be the only source of light or do I want more than one- moon? Stars? Two suns?
-          What exactly are my interactions going to be, can you pluck a flower, for example?
-          You can only see some stuff when the lights are off/ it’s night
-          If I have day and night, how are things different during the day and at night? Do things hibernate/ go to sleep? How do they wake up?
