Prototype blog post 1. hello.
My prototype isn't too much of an actual prototype so much as a moodboard/ idea dump so far. My capstone idea is a little difficult to put into words at the moment but as an extension to what I wrote in my proposal, it is essentially a VR game/experience without a goal. I think I just got tired of being told to make art with meaning instead of just making what I liked  that I started thinking about how we view productivity and ambition (with all due respect to all my IM and VisArts classes- I loved them). While I can't deny that they have their uses, art does not necessarily have to follow the ideals of capitalism. I am reminded of why people don't see games or fashion as art. Something about making art for no other reason than that I think it is cool has a certain appeal.
I want the game to be exploratory, where the player can experience the world for as little or as long as they want, interacting with the terrain and creatures.
Since VR can be heavy on mobile devices, I plan to make and use low poly models. It also matches the aesthetic I'm going for. I'm not trying to be realistic- the environment will be a fantasy one.
The book I referenced in my proposal (The Mushroom at the End of the World) talks about lateral learning as opposed to simply thinking ahead all the time. I wanted my capstone to embody this in some way, so I tried to come up with ways of compelling (for lack of a better word) with the environment and themselves in it. I'm planning to switch around (maybe user controlled, maybe not) aspects of the environment like light and sound. How does someone interact with a VR space without sight? What do you focus on when you can't hear anything. I may even switch off gravity- because I can.
I'm in the process of creating my environment and should have some concept art by next time.
Environment:
Light source- timer for day and night.
Sky 
clouds
Water 
Rocks
Landforms- waterfalls, caves- procedural terrain
Plants
Living things- animals, bugs etc.

Swarms of bugs (will make my own model probably):
https://indiewatch.net/2018/12/19/tutorial-how-to-make-a-swarm-of-firebugs-for-your-game/

Spawn fish: 
https://www.youtube.com/watch?v=Duy4ZrT8STw

Flocking algorithm for fish, birds, bugs:
https://www.youtube.com/watch?v=eMpI1eCsIyM
https://www.youtube.com/watch?v=bqtqltqcQhw

Ant colonies and slime generation:
https://www.youtube.com/watch?v=X-iSQQgOd1A

Procedural environment:
https://www.youtube.com/watch?v=lctXaT9pxA0&list=RDCMUCmtyQOKKmrMVaKuRXz02jbQ&index=3
(Sebastian Lague procedural environment/landmass etc)

Place elements in a procedural environment:
https://www.youtube.com/watch?v=7WcmyxyFO7o&list=RDCMUCmtyQOKKmrMVaKuRXz02jbQ&index=23

Lava:
https://www.youtube.com/watch?v=MyNyoxEqD8E

