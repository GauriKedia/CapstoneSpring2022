Blog post 3

The more I think about my project, the more daunting it seems. I think I want to do my own soundscapes and tracks (with some amount of help). 
I have been trying to create creatures of the environment but while they sound cool and interesting in my head, they’re going to be difficult to model and rig. 
I thought of another interaction (sort of): eye tracking- there is an area with some creatures (maybe they come out at night and have glowing eyes) whose eyes track you as you move around. Kind of creepy which is not the vibe I’m going for, but maybe I could make it more fun with the sound or making the creatures themselves not scary.

Seeing as I’ve decided to do everything from scratch, I’m doing research on games, gameplay and game environments (as seen in some of the photos on the next slide). I think that while this has not yet produced something concrete and tangible, it is definitely progress in the right direction, so I uploaded screenshots of what I’m looking at right now to create the environment. Taking written notes helps but uploading an image of those seems a bit redundant.

I’m also reading Jesper Juul’s papers on gameplay and analysis, which I think will help me decide my interactions and this idea of not having one specific goal. I do want my project to be grounded in some foundation of understanding of how we play games; this will, I hope, prove my seriousness about the idea, and not make it sound like taking the easy way out with an open narrative structure. I tend to rationalise my reasons for doing things because they seem cool and interesting, but I want to understand why they are cool and interesting. 

I’m also looking at character design and style sheets by animators in the hopes that they will help me design elements of my environment. 
I know this blog post seems haphazard, even for me. It reflects my process and progress. This is the only feasible way I see of diving into my work, to make sure I’m considering as many aspects of my project as possible. I’ve uploaded more than two photos, not because I’m trying to over achieve (imagine that) but because I’m taking in bits of information and inspiration from so many different places. Given my open ended concept and perhaps a dearth of structure, I’m trying to supplement the narrative of my experience with some amount of theoretical background.

